import json
from datetime import datetime
from dateutil.tz import gettz

from thasus.website_scanner import update_website_freshness


def lambda_handler(event, context):

    # get rows
    # get data from beautiful soup
    # calculate hash
    # if hash is different than before, update row, and state to scrape
    run_mode = event['run_mode']

    if run_mode != 'check_domains':
        return {
            'statusCode': 200,
            'body': json.dumps(f"Thasus tested at {get_now()}")
        }

    update_website_freshness(get_now())
    return {
        'statusCode': 200,
        'body': json.dumps(f"Thasus executed at {get_now()}")
    }


def get_now():
    now_pacific = datetime.now(gettz('US/Pacific'))
    return now_pacific.isoformat(timespec='seconds')

