import hashlib
import traceback
from urllib.request import Request, urlopen
from bs4 import BeautifulSoup

from thasus.persistence.discovered_domains import get_all_domains

DAY_IN_MILLIS = 24 * 60 * 60 * 1000
WEEK_IN_MILLIS = 7 * DAY_IN_MILLIS


def update_website_freshness(current_time_epoch):
    freshness_threshold = current_time_epoch - DAY_IN_MILLIS
    all_domains = get_all_domains()
    for domain in all_domains:
        if domain['scanned_at'] > freshness_threshold:
            continue
        page_content = get_page_content(domain)
        page_content_hash = hashlib.md5(page_content).hexdigest()
        if 'website_hash' not in domain or domain['website_hash'] != page_content_hash:
            domain['website_hash'] = page_content_hash
            domain['content_status'] = 'extract'

        domain['scanned_at'] = current_time_epoch


def get_page_content(domain):
    try:
        hdr = {
            'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) '
                          'Chrome/102.0.0.0 Safari/537.36',
        }

        req = Request(domain['url'], headers=hdr)
        page = urlopen(req)
        soup = BeautifulSoup(page, 'html.parser')
        return soup.getText()
    except Exception as e:
        print(f"Unable to get camp data for {domain['url']}")
        print(e)
        print(traceback.format_exc())
